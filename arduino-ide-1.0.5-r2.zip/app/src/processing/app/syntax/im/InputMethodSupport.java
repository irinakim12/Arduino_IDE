package processing.app.syntax.im;

import java.util.Locale;
import java.awt.Rectangle;
import java.awt.event.InputMethodEvent;
import java.awt.event.InputMethodListener;
import java.awt.font.TextHitInfo;
import java.awt.im.InputMethodRequests;
import java.text.AttributedCharacterIterator;

import processing.app.syntax.JEditTextArea;

/**
 * Support in-line Japanese input for PDE. (Maybe Chinese, Korean and more)
 * This class is implemented by Java Input Method Framework and handles
 * If you would like to know more about Java Input Method Framework,
 * Please see http://java.sun.com/j2se/1.5.0/docs/guide/imf/
 * 
 * This class is implemented to fix Bug #854.
 * http://dev.processing.org/bugs/show_bug.cgi?id=854
 *  
 * @author Takashi Maekawa (takachin@generative.info)
 */
public class InputMethodSupport implements InputMethodRequests,
    InputMethodListener {

  private int committed_count = 0;
  private CompositionTextManager textManager;
  private boolean isKO = false;

  public InputMethodSupport(JEditTextArea textArea) {
    textManager = new CompositionTextManager(textArea);
    textArea.enableInputMethods(true);
    textArea.addInputMethodListener(this);

	isKO = Locale.getDefault().getLanguage() == "ko" ? true : false;
  }

  public Rectangle getTextLocation(TextHitInfo offset) {
    return textManager.getTextLocation();
  }

  public TextHitInfo getLocationOffset(int x, int y) {
    return null;
  }

  public int getInsertPositionOffset() {
    return textManager.getInsertPositionOffset();
  }

  public AttributedCharacterIterator getCommittedText(int beginIndex,
      int endIndex, AttributedCharacterIterator.Attribute[] attributes) {
    return textManager.getCommittedText(beginIndex, endIndex);
  }

  public int getCommittedTextLength() {
    return committed_count;
  }

  public AttributedCharacterIterator cancelLatestCommittedText(
      AttributedCharacterIterator.Attribute[] attributes) {
    return null;
  }

  public AttributedCharacterIterator getSelectedText(
      AttributedCharacterIterator.Attribute[] attributes) {
    return null;
  }

  /**
   * Handles events from InputMethod.
   * This method judges whether beginning of input or 
   * progress of input or end and call related method.
   * 
   * @param event event from Input Method.
   */

  private int textIsNullCount = 0;

  public void inputMethodTextChanged(InputMethodEvent event) {
    AttributedCharacterIterator text = event.getText();
    committed_count = event.getCommittedCharacterCount();

	/*
	 * In case of Korean IM, the null text would be input if any
	 * ASCII is input during Korean Character is composed.
	 * So it should be returned without any processing in this case.
	 *
	 * If the composed Korean character would be deleted completely,
	 * then the null text will be input twicely. In that case the second
	 * null text should be processed and the composed Korean character
	 * should be deleted.
	 * 
	 */
	if(isKO && text == null) {
      // increase textIsNullCount by 1
	  textIsNullCount++;

	  // if textIsNullCount is 1, then return
	  if(textIsNullCount == 1)
	  {
        return;
	  }
    }
    // reset textIsNullCount to 0
    textIsNullCount = 0;

/*
 * Debug
 * -----
 * print the composed character, committed_count and location with
 * %c[committed_count](x,y,width, height) format.
 */
/* 
    if(text != null) {
      for(char c=text.first(); c != AttributedCharacterIterator.DONE; c = text.next()) {
        System.out.print(String.format("%c", c));
      }
    }
    System.out.print(String.format("[%d]", committed_count));

    Rectangle rect = textManager.getTextLocation();
    System.out.print(String.format("(%d,%d,%d,%d)\r\n", rect.x, rect.y, rect.width, rect.height));  
//*/

    if(isFullWidthSpaceInput(text)){
      textManager.insertFullWidthSpace();
      caretPositionChanged(event);
      return;
    }
    if(isBeginInputProcess(text, textManager)){
      textManager.beginCompositionText(text, committed_count);
      caretPositionChanged(event);
      return;
    }
    if (isInputProcess(text)){
      textManager.processCompositionText(text, committed_count);
      caretPositionChanged(event);
      return;
    }
    textManager.endCompositionText(text, committed_count);
    caretPositionChanged(event);
  }
  
  private boolean isFullWidthSpaceInput(AttributedCharacterIterator text){
    if(text == null)
      return false;
    if(textManager.getIsInputProcess())
      return false;
    return (String.valueOf(text.first()).equals("\u3000"));
  }
  
  private boolean isBeginInputProcess(AttributedCharacterIterator text, CompositionTextManager textManager){
    if(text == null)
      return false;
    if(textManager.getIsInputProcess())
      return false;
    return (isInputProcess(text));
  }

  private boolean isInputProcess(AttributedCharacterIterator text){
    if(text == null)
      return false;
    return (text.getEndIndex() - (text.getBeginIndex() + committed_count) > 0);
  }

  public void caretPositionChanged(InputMethodEvent event) {
    event.consume();
  }
}
